#!/usr/bin/env python3
"""Publish the natural-language pilot without replacing historical event results."""
import argparse
import json
import re
from pathlib import Path
import shutil
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from listen_audio_postprocess.recipes import read_listener_audio, masks
from p2_listen.contracts import atomic_json, sha
from build_listen_visual_prompt_versions_review import compact_mask


def main():
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True)
    p.add_argument('--output-name',default='natural_caption')
    p.add_argument('--compare-run',type=Path,action='append',default=[])
    a=p.parse_args();run=a.run.resolve()
    if Path(a.output_name).name!=a.output_name:raise ValueError('Single output directory name required')
    protocol=json.loads((run/'protocol.json').read_text())
    comparison_runs=[]
    for directory in a.compare_run:
        directory=directory.resolve();cp=json.loads((directory/'protocol.json').read_text())
        title='第一版：原始整段描述，无补充点头' if not cp.get('prompt_version') else '上一版：固定 prompt v1'
        comparison_runs.append(dict(directory=directory,title=title,run_id=directory.name))
    direct=protocol.get('task')=='nod_guided_direct_annotation'
    case_file=run/'known_case_comparison.json'
    case_notes={c['sample_id']:c['note'] for c in json.loads(case_file.read_text())['cases']} if case_file.exists() else {}
    base=ROOT/'data_previews/listen_benchmark_review/native_simple';out=base/a.output_name;out.mkdir(exist_ok=True)
    old=json.loads((base/'comparison.json').read_text());historical={s['id']:s for s in old['samples']}
    rows=json.loads((run/'manifest.json').read_text());samples=[]
    for row in rows:
        sid=row['sample_id'];recipe=json.loads(Path(row['listener_audio_recipe']).read_text())
        wave,sr,meta=read_listener_audio(recipe);gate,extra,info=masks(recipe)
        media=out/'media'/sid;media.mkdir(parents=True,exist_ok=True)
        paths={'listener.wav':Path(recipe['source']['path']), 'video.mp4':(base/historical[sid]['video']).resolve(),
               'speaker.wav':Path(row['source_reference']['roles']['speaker']['audio_wav']['path'])}
        for name,path in paths.items():
            dest=media/name
            if dest.is_symlink(): assert dest.resolve()==path.resolve()
            elif dest.exists(): raise ValueError(f'Unexpected physical media: {dest}')
            else: dest.symlink_to(path)
        result_path=run/'results'/(sid+'.json');result=json.loads(result_path.read_text()) if result_path.exists() else None
        if result:
            assert result['recipe_sha256']==row['recipe_sha256']
            assert result['input_evidence']['audio_identity']['processed_waveform_sha256']==meta['processed_waveform_sha256']
            result['review_flags']=list(result['review_flags'])
            if re.search(r'\b(contemplative|pensive|thoughtful|attentive|engaged|curious|curiosity|concentrat\w*|interested|interest|acknowledg\w*)\b',result['caption'],re.I):
                result['review_flags'].append('mental_state_wording_review')
            if (direct and row['audio_preflight']['full_silence'] and re.search(r'["“][^"”]+["”]',result['caption'])
                    and re.search(r'\b(say|says|saying|said|speak|speaks|speaking|utter|utters|uttering)\b',result['caption'],re.I)):
                result['review_flags'].append('quoted_content_in_fully_silent_audio_review')
            if direct and re.search(r'\b(supplementary|provided (?:data|intervals)|detector)\b',result['caption'],re.I):
                result['review_flags'].append('mentions_input_metadata_in_caption')
            if protocol.get('prompt_version'):
                if (row['audio_preflight']['full_silence'] and re.search(
                        r'\b(?:while (?:speaking|talking|laughing)|as (?:he|she|they) (?:speaks|talks|laughs))\b',result['caption'],re.I)):
                    result['review_flags'].append('silent_speech_claim_review')
                if re.search(r'\b(?:\d+(?:\.\d+)?|one|two|three|four|five|six|seven|eight|nine|ten)(?:[- ](?:point[- ]\w+|and[- ]\w+))?[- ]seconds?\b',result['caption'],re.I):
                    result['review_flags'].append('numeric_timing_review')
                if result['caption'].startswith('Assistant:'):
                    result['review_flags'].append('assistant_prefix_review')
            result['review_flags']=list(dict.fromkeys(result['review_flags']))
        focus={
            'naturalistic_V00_S0805_I00000126_local_f7c1fb6d13ca':'此前你确认过两次 Right 和五次 yeah。本轮文字也保留了这些词；请检查发声同时的点头是否仍被遗漏或只写成转头。',
            'naturalistic_V02_S5193_I00000190_local_60bde84ffa78':'此前你确认过 Uh huh 和 Yeah。本轮只明确写出 Yeah；请听净化音轨核对 Uh huh 是否遗漏，并检查 contemplative、pensive、thoughtful 等推演措辞。',
            'naturalistic_V00_S0699_I00000500_local_3491a3549642':'本轮写出两次 Okay，请核对是否确实两次、先后关系是否正确，以及笑和点头是否完整。',
            'naturalistic_V03_S2043_I00000338_local_32d3f86103cd':'注意区分可见笑容与实际笑声：请检查 while still laughing 是否把短暂笑声延长到了后面的遮嘴动作。',
        }
        sample=dict(id=sid,short=sid.split('_')[2],duration=row['duration_s'],video=f'media/{sid}/video.mp4',
                    audio=dict(original=f'media/{sid}/listener.wav',speaker=f'media/{sid}/speaker.wav',sample_rate=sr,
                               source_samples=len(wave),gate=compact_mask(gate),extra=compact_mask(extra),
                               processed_full_silence=row['audio_preflight']['full_silence'],
                               processed_pcm_sha256=meta['processed_waveform_sha256']),
                    recipe_provenance=row['audio_preflight']['provenance']['mode'],result=result,
                    focus=focus.get(sid,''),
                    historical_events=historical[sid]['results']['native_baseline'].get('raw_events',[]),
                    historical_url='../?sample='+sid)
        if 'nod_supplement' in row:
            sample['nod']=row['nod_supplement']
            if not direct:
                sample['prior_caption']=row['nod_supplement']['prior_caption']
                sample['caption_changed']=bool(result and result['caption']!=sample['prior_caption'])
            if not direct and result and sample['nod']['events'] and not sample['caption_changed']:
                result['review_flags'].append('nod_cues_caption_unchanged')
            if result and sample['nod']['events'] and re.search(r'\b(single|twice|two|three|first|second|final)\b',result['caption'],re.I):
                result['review_flags'].append('verify_actual_nod_count_not_interval_count')
            if sample['nod']['events']:
                sample['focus']='请逐处播放点头候选，检查描述是否放在正确阶段、是否误把区间数当作点头次数，以及是否出现没有依据的发声或其他动作。'+(' 本条原文没有变化，需要重点检查候选是否被忽略。' if not direct and result and not sample['caption_changed'] else '')
                if not direct and sid=='naturalistic_V03_S1713_I00000089_local_1d82137fda7c':
                    sample['focus']+=' 本条新增描述包含再次触碰颈部等非点头细节，尤其需要核对是否真实重复。'
            elif direct:
                sample['focus']='本条没有补充点头区间，但同样从音视频重新打标。请检查模型是否独立识别到动作，并核对静音时是否虚构发声。'
        if sid in case_notes:sample['focus']=case_notes[sid]+' '+sample['focus']
        sample['caption_comparisons']=[]
        for cr in comparison_runs:
            other=json.loads((cr['directory']/'results'/(sid+'.json')).read_text())
            assert result and other['recipe_sha256']==result['recipe_sha256']
            assert other['input_evidence']['audio_identity']==result['input_evidence']['audio_identity']
            assert other['input_evidence']['video_evidence']==result['input_evidence']['video_evidence']
            sample['caption_comparisons'].append(dict(title=cr['title'],run_id=cr['run_id'],caption=other['caption'],finish_reason=other['finish_reason']))
        samples.append(sample)
    finished=[s for s in samples if s['result']]
    stats=dict(samples=len(samples),completed=len(finished),nonempty=sum(bool(s['result']['caption'].strip()) for s in finished),
               finished_normally=sum(s['result']['finish_reason']=='stop' for s in finished),
               full_silence=sum(s['audio']['processed_full_silence'] for s in samples),
               possible_interpretation=sum('possible_interpretation_review' in s['result']['review_flags'] for s in finished),
               total_inference_seconds=sum(s['result']['seconds'] for s in finished),human_ground_truth=False)
    payload=dict(run_id=run.name,stats=stats,samples=samples,protocol=protocol)
    if protocol.get('task') in ('nod_guided_revision','nod_guided_direct_annotation'):
        if not direct:payload['run_id']=run.parent.name
        stats.update(nod_candidate_clips=sum(bool(s['nod']['events']) for s in samples),
                     nod_candidate_intervals=sum(len(s['nod']['events']) for s in samples),
                     no_nod_reused=sum(bool(s['result'] and s['result'].get('reused_no_nod')) for s in samples),
                     nod_word_mentions=sum(bool(s['result'] and re.search(r'\bnod\w*\b',s['result']['caption'],re.I)) for s in samples if s['nod']['events']))
        stats['nod_cues_but_unchanged']=sum(bool(s['result'] and s['nod']['events'] and not s.get('caption_changed',True)) for s in samples)
        stats['new_inference_seconds']=sum(s['result']['seconds'] for s in finished if not s['result'].get('reused_no_nod'))
        if direct:stats.update(fresh_inferences=len(finished),old_caption_inputs=0)
    if protocol.get('prompt_version'):
        stats.update(retried_samples=sum(len(s['result'].get('attempts',[]))>1 for s in finished),
                     unresolved_generation_failures=sum(not s['result'].get('generation_checks_passed',False) for s in finished))
    atomic_json(out/'review.json',payload);atomic_json(run/'review_summary.json',stats)
    shutil.copy2(ROOT/'scripts/listen_native_caption_review.html',out/'index.html')
    js=(ROOT/'scripts/listen_visual_prompt_review_audio.js').read_text()
    # Original historical clips are PCM24; completed full-corpus sources are PCM16.
    # Decode integer PCM exactly, then apply the same two float32 multiplies.
    js=js.replace("bits !== 16", "![16,24].includes(bits)").replace("bytes / 2 !== s.audio.source_samples", "bytes / (bits/8) !== s.audio.source_samples")
    js=js.replace("const n = bytes / 2,", "const n = bytes / (bits/8),")
    js=js.replace("(dv.getInt16(start + 2 * i, true) / 32768)", "readSample(i)")
    js=js.replace("    for (let i = 0; i < n; i++) out[i]", "    const readSample = i => { if(bits===16) return dv.getInt16(start+2*i,true)/32768; const p=start+3*i; let v=dv.getUint8(p)|(dv.getUint8(p+1)<<8)|(dv.getUint8(p+2)<<16); if(v&0x800000)v-=0x1000000; return v/8388608; };\n    for (let i = 0; i < n; i++) out[i]")
    (out/'audio.js').write_text(js)
    html=(out/'index.html').read_text()
    fontpath=Path('/tmp/v8_browser_libs/extracted/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    if fontpath.exists():
        from fontTools.ttLib import TTFont
        from fontTools import subset
        f=TTFont(fontpath,fontNumber=2);options=subset.Options();options.desubroutinize=True;options.layout_features=[]
        ss=subset.Subsetter(options);ss.populate(text=html+js+json.dumps(payload,ensure_ascii=False));ss.subset(f);f.flavor='woff';f.save(out/'review.woff')
    index=base/'index.html';text=index.read_text();marker=f'<!-- {a.output_name}-entry -->'
    if marker not in text:
        backup=base/f'index.before_{a.output_name}_20261030.html'
        if not backup.exists():shutil.copy2(index,backup)
        title='新增：点头时间线索融入整段自然语言描述' if payload['protocol'].get('task')=='nod_guided_revision' else '新增：净化 listener 音轨＋原生视听 · 整段自然语言描述'
        if direct:title='新增：独立重新打标 · 音视频＋点头区间 · 不输入旧描述'
        if protocol.get('prompt_version'):title='固定 prompt v1：独立视听描述＋点头线索＋真实静音标记'
        if protocol.get('prompt_style')=='first_plus_evidence':title='新试验：第一版描述方式＋精简点头与静音说明（三版有声对照）'
        entry=marker+f'<section class="panel"><strong>{title}</strong><p>同一批50条，描述动作顺序、持续状态、同时发生与真实重复，不输出逐事件时间戳表。</p><a href="{a.output_name}/">打开有声复核页面 →</a></section>'
        assert '<main>' in text;index.write_text(text.replace('<main>','<main>'+entry,1))
    print(json.dumps(stats,ensure_ascii=False))


if __name__=='__main__': main()
