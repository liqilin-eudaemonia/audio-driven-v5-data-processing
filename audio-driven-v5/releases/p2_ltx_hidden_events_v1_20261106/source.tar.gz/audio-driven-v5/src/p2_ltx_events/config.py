"""An independent identity; old checkpoints cannot silently acquire a new loss."""
import math
from pathlib import Path
from p2_listen.contracts import ROOT,read,sha
from p2_whisper_event_feature.config import validate as original_validate
from . import VERSION

DEFAULT=ROOT/'configs/p2_ltx_hidden_events_current500h_20261106.json'
TEMPORAL_CLASSES={'video':['head_nod','head_shake','smile','laugh','frown','surprise'],
                  'audio':['listener_vocalization']}
CURRENT_TEMPORAL_CLASSES={'video':TEMPORAL_CLASSES['video']+['brow_lowering','brows_raised'],
                          'audio':TEMPORAL_CLASSES['audio']}


def validate(c,formal=True):
    original_validate(c,formal=formal)
    s=c.get('hidden_event_supervision',{})
    if (c.get('hidden_event_experiment')!=VERSION or s.get('readout')!='last_block_before_output'
            or s.get('classes') not in (TEMPORAL_CLASSES,CURRENT_TEMPORAL_CLASSES)
            or s.get('label_policy')!='historical-weak-intervals-v1'):
        raise ValueError('Expected explicit LTX hidden readout and historical temporal taxonomy')
    for key in ('clip_weight','temporal_weight','background_weight'):
        if isinstance(s.get(key),bool) or not isinstance(s.get(key),(float,int)) or not math.isfinite(s[key]) or s[key]<0:
            raise ValueError('Invalid hidden Event '+key)
    if s['clip_weight']+s['temporal_weight']<=0 or s['background_weight']>1:
        raise ValueError('Invalid hidden Event weights')
    if not c.get('temporal_labels') or not c.get('hidden_event_parent_config'):
        raise ValueError('Frozen temporal labels and parent configuration required')
    if Path(c['output']).resolve()==Path(read(c['hidden_event_parent_config'])['output']).resolve():
        raise ValueError('Hidden Event training requires a new output directory')
    return c


def validate_baseline(c,parent):
    validate(c)
    added={'hidden_event_experiment','hidden_event_supervision','temporal_labels','hidden_event_parent_config','output'}
    if c.get('current_cache_index'):
        added|={'current_cache_index','current_source','j_cache','plan_cache','clip_labels','teacher_cache','whisper_cache','duration_sampling','training'}
        if {k:v for k,v in c['training'].items() if k not in ('global_batch','steps')}!={k:v for k,v in parent['training'].items() if k not in ('global_batch','steps')}:
            raise ValueError('Current data arm changed optimizer or training precision policy')
    if {k:v for k,v in c.items() if k not in added}!={k:v for k,v in parent.items() if k not in added}:
        raise ValueError('Hidden Event arm changed parent data, conditioning, optimizer or schedule')
    return c


def load(path=DEFAULT):return validate(read(path))


def source_identity():
    from p2_whisper_event_feature.config import source_identity as original
    result=original()
    for p in sorted(Path(__file__).parent.glob('*.py')):result[str(p)]=sha(p)
    p=ROOT/'scripts/p2_ltx_events.py';result[str(p)]=sha(p)
    for name in ('qwen_hidden','gemma_cache','av_cache','whisper_cache','teacher_cache'):
        p=ROOT/('scripts/p2_j_current_'+name+'.py');result[str(p)]=sha(p)
    for name in ('scripts/check_glare_headshake_direction.py','scripts/check_glare_expression_gate.py','src/listen_benchmark/caption_guard.py'):
        p=ROOT/name;result[str(p)]=sha(p)
    return result
